# Installation

## Requirements

libfreetype libGLEW libpng

both x64 and x32 versions

```
make
sudo make install
```

# Usage

Please refer to https://github.com/nullifiedcat/xoverlay-glez-example