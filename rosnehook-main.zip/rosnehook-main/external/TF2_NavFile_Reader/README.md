TF2 NavFile Reader

How to use:

1.) Include CNavFile.h

2.) Instantiate CNavFile, map name argument in 
constructor is intended to work with level name from engine->GetLevelName() or with "mapname" string from "server_spawn" GameEvent

3.) Check if m_isOK -> no errors while reading

4.) Done!

License: http://www.wtfpl.net/txt/copying/
Credits: Source Engine SDK by Valve -> cool and good header files
