# Best Cathook Paste (Currently)

Rosnehook is training software for Team Fortress 2, available exclusively for Linux operating systems.

Rosnehook is not responsible for any bans.

## How to Install

Open a terminal window and enter the following command:

    bash <(wget -qO- https://raw.githubusercontent.com/RosneBurgerworks/One-in-all-rosnehook-install/master/install-all)

For a more in-depth tutorial, watch this [video](https://www.youtube.com/watch?v=bNoTEz2_BqY).

## Issues or Questions?

Need support?

Join the [Discord server](https://discord.gg/XqBRXE5QVy) or visit the [issues page](https://github.com/RosneBurgerworks/temprosnehook/issues).

## This software is for educational purposes only.

Tom, the glorious. Is the best!
